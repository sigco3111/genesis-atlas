#!/bin/bash
set -e
cp -r /tmp/payload/data /tmp/payload/README.md .
cp /tmp/payload/tools/fix_labels.py tools/
