#!/bin/bash
set -eo pipefail
cp /tmp/payload/js/sim.js js/sim.js
cp /tmp/payload/js/render.js js/render.js
cp /tmp/payload/js/main.js js/main.js
cp /tmp/payload/test/ships.mjs test/ships.mjs
cp /tmp/payload/README.md README.md
node --check js/sim.js
node --check js/render.js
node --check js/main.js
node test/ships.mjs | tail -3
node test/smoke.mjs | tail -2
