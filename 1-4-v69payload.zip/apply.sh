#!/bin/bash
set -e
cp /tmp/payload/files/js/spectate.js js/spectate.js
cp /tmp/payload/files/js/main.js js/main.js
cp /tmp/payload/files/test/spectate.mjs test/spectate.mjs
cp /tmp/payload/files/README.md README.md
git config user.name "sigco3111"
git config user.email "sigco3111@users.noreply.github.com"
git add js/spectate.js js/main.js test/spectate.mjs README.md
git commit -m "v69: 주요 전투 자동 관전 - 켜 두면 양측 합산 3천 이상의 큰 교전에 카메라가 알아서 따라붙고, 지도를 움직이면 그 교전만 풀림"
