set -e
REPO="${GITHUB_WORKSPACE:-$(pwd)}"
cd /tmp/payload
cp js/render.js "$REPO/js/"
echo applied
