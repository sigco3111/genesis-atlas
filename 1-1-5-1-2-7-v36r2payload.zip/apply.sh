#!/bin/bash
set -e
cp /tmp/payload/js/warhist.js js/warhist.js
cp /tmp/payload/js/main.js js/main.js
cp /tmp/payload/test/warhist.mjs test/warhist.mjs
node --check js/main.js
node --check js/warhist.js
node test/warhist.mjs
node test/powers.mjs
node test/smoke.mjs
