#!/bin/bash
set -e
cp /tmp/payload/main.js js/main.js
cp /tmp/payload/sim.js js/sim.js
cp /tmp/payload/style.css .
cp /tmp/payload/README.md .
mkdir -p test
cp /tmp/payload/smoke.mjs test/smoke.mjs
echo "v21 payload applied: remove divine power resource - unlimited powers"
