#!/bin/bash
set -e
cp /tmp/payload/js/cmptrend.js js/cmptrend.js
cp /tmp/payload/js/main.js js/main.js
cp /tmp/payload/js/sim.js js/sim.js
cp /tmp/payload/style.css style.css
cp /tmp/payload/test/cmptrend.mjs test/cmptrend.mjs
cp /tmp/payload/test/cmp.mjs test/cmp.mjs
cp /tmp/payload/README.md README.md
node test/cmptrend.mjs
node test/cmp.mjs
