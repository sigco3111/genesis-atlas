#!/bin/bash
set -e
cp /tmp/payload/js/main.js js/main.js
cp /tmp/payload/js/sim.js js/sim.js
cp /tmp/payload/js/render.js js/render.js
cp /tmp/payload/index.html index.html
cp /tmp/payload/style.css style.css
cp /tmp/payload/README.md README.md
mkdir -p test
cp /tmp/payload/test/track.mjs test/track.mjs
