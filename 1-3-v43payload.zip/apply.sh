#!/bin/bash
set -eo pipefail
cp /tmp/payload/js/econ.js js/econ.js
cp /tmp/payload/js/sim.js js/sim.js
cp /tmp/payload/js/render.js js/render.js
cp /tmp/payload/js/main.js js/main.js
cp /tmp/payload/index.html index.html
cp /tmp/payload/style.css style.css
cp /tmp/payload/test/econ.mjs test/econ.mjs
cp /tmp/payload/test/powers.mjs test/powers.mjs
cp /tmp/payload/README.md README.md
for f in js/*.js; do node --check $f; done
node test/ships.mjs | tail -3
node test/powers.mjs | tail -2
node test/smoke.mjs | tail -2
