set -e
cd "$GITHUB_WORKSPACE"
rm -f 1-ga-payload-v100.zip
cp -r /tmp/payload/files/. .
echo "applied:"; grep -c '?v=100' index.html js/main.js
