#!/bin/bash
set -e
cp /tmp/payload/js/render.js js/render.js
cp /tmp/payload/js/warhist.js js/warhist.js
cp /tmp/payload/test/warhist.mjs test/warhist.mjs
node --check js/render.js
node --check js/warhist.js
node test/warhist.mjs
node test/powers.mjs
node test/smoke.mjs
