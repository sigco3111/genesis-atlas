#!/bin/bash
set -e
# cwd = repo root (workflow run step)
cp -r /tmp/payload/data /tmp/payload/README.md .
mkdir -p tools/hyde
cp /tmp/payload/tools/konames.py /tmp/payload/tools/fix_labels.py /tmp/payload/tools/build_eras.py /tmp/payload/tools/build_eras_fast.py tools/
cp -r /tmp/payload/tools/hyde/pops tools/hyde/
