#!/bin/bash
set -e
cp /tmp/payload/js/labels.js js/labels.js
cp /tmp/payload/js/render.js js/render.js
cp /tmp/payload/js/main.js js/main.js
cp /tmp/payload/test/labels.mjs test/labels.mjs
cp /tmp/payload/README.md README.md
node test/labels.mjs
