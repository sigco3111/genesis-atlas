#!/bin/bash
set -e
cp /tmp/payload/js/main.js js/main.js
cp /tmp/payload/style.css style.css
node --check js/main.js
node test/powers.mjs > /dev/null
node test/smoke.mjs > /dev/null
