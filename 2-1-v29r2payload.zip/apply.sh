#!/bin/bash
set -e
cp /tmp/payload/main.js js/main.js
cp /tmp/payload/sim.js js/sim.js
cp /tmp/payload/README.md README.md
