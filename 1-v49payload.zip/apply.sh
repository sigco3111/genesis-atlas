#!/bin/bash
cp /tmp/payload/js/units.js js/units.js
cp /tmp/payload/js/render.js js/render.js
cp /tmp/payload/units_test.mjs test/units.mjs
