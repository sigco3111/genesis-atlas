#!/bin/bash
set -e
cp /tmp/payload/js/warhist.js js/warhist.js
cp /tmp/payload/js/sim.js js/sim.js
cp /tmp/payload/js/main.js js/main.js
cp /tmp/payload/style.css style.css
cp /tmp/payload/test/warhist.mjs test/warhist.mjs
cp /tmp/payload/README.md README.md
node test/warhist.mjs
node test/warwatch.mjs
node test/cmp.mjs
