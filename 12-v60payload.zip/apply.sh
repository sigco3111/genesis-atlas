#!/bin/bash
for f in /tmp/payload/js/*.js; do cp "$f" js/$(basename "$f"); done
cp /tmp/payload/units_test.mjs test/units.mjs
[ -f /tmp/payload/armyreg.mjs ] && cp /tmp/payload/armyreg.mjs test/armyreg.mjs
