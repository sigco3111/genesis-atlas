#!/bin/bash
set -eo pipefail
cp /tmp/payload/main.js js/main.js
cp /tmp/payload/style.css style.css
node test/ships.mjs | tail -1
