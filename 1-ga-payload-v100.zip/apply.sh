set -e
cd "$GITHUB_WORKSPACE"
cp -r /tmp/payload/files/. .
echo "applied payload files:"; ls -la index.html style.css js | head
