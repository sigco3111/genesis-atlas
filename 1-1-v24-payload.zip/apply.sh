#!/bin/bash
set -e
cp /tmp/payload/js/main.js js/main.js
cp /tmp/payload/style.css style.css
cp /tmp/payload/README.md README.md
