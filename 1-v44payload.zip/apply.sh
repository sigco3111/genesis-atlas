set -e
cp /tmp/payload/js/econ.js js/econ.js
cp /tmp/payload/js/sim.js js/sim.js
cp /tmp/payload/js/render.js js/render.js
cp /tmp/payload/js/main.js js/main.js
cp /tmp/payload/test/econ.mjs test/econ.mjs
cp /tmp/payload/test/ships.mjs test/ships.mjs
cp /tmp/payload/README.md README.md
