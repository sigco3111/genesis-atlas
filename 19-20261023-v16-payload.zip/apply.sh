set -e
# remove misnamed files from the earlier broken web upload (numeric prefixes)
rm -f data/era/[0-9]*-*.json js/14-main.js js/15-sim.js 16-index.html 17-README.md 18-LICENSE-data-gpl3.txt
# install era feature files
mkdir -p data/era js test tools
cp /tmp/payload/data/era/*.json data/era/
cp /tmp/payload/js/main.js /tmp/payload/js/sim.js js/
cp /tmp/payload/index.html /tmp/payload/README.md /tmp/payload/LICENSE-data-gpl3.txt /tmp/payload/.gitignore .
cp /tmp/payload/test/era.mjs test/
cp -r /tmp/payload/tools/. tools/
rm -rf tools/__pycache__
