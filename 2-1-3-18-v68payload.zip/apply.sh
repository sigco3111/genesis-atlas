#!/bin/bash
set -e
cp /tmp/payload/files/js/battles.js js/battles.js
cp /tmp/payload/files/js/units.js js/units.js
cp /tmp/payload/files/js/sim.js js/sim.js
cp /tmp/payload/files/js/main.js js/main.js
cp /tmp/payload/files/style.css style.css
cp /tmp/payload/files/README.md README.md
cp /tmp/payload/files/test/battles.mjs test/battles.mjs
git config user.name "sigco3111"
git config user.email "sigco3111@users.noreply.github.com"
git add js/battles.js js/units.js js/sim.js js/main.js style.css README.md test/battles.mjs
git commit -m "v68: 지휘관 전적 - 교전이 마감될 때 지휘관별 참전·승패·주요 전투를 누적해 전쟁 탭에서 보여 줌"
