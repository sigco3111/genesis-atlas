#!/bin/bash
set -e
cp /tmp/payload/js/warwatch.js js/warwatch.js
cp /tmp/payload/js/render.js js/render.js
cp /tmp/payload/js/main.js js/main.js
cp /tmp/payload/style.css style.css
cp /tmp/payload/test/warwatch.mjs test/warwatch.mjs
cp /tmp/payload/README.md README.md
node test/warwatch.mjs
