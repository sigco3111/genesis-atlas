set -e
cp -f /tmp/payload/index.html /tmp/payload/README.md .
cp -f /tmp/payload/js/units.js /tmp/payload/js/sim.js /tmp/payload/js/render.js /tmp/payload/js/main.js js/
cp -f /tmp/payload/test/units.mjs test/
