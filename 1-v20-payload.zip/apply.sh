#!/bin/bash
set -e
cp /tmp/payload/index.html /tmp/payload/style.css /tmp/payload/README.md .
cp /tmp/payload/main.js js/main.js
echo "v20 payload applied: labeled panel fold button + visible labeled handle"
