set -e
REPO="${GITHUB_WORKSPACE:-$(pwd)}"
cd /tmp/payload
cp js/units.js js/render.js "$REPO/js/"
cp test/units.mjs "$REPO/test/"
cp README.md "$REPO/README.md"
echo applied
