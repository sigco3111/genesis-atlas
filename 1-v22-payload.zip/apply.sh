set -e
cp /tmp/payload/js/main.js js/main.js
cp /tmp/payload/index.html index.html
cp /tmp/payload/README.md README.md
