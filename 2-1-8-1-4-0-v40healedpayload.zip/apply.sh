#!/bin/bash
set -e
cp /tmp/payload/js/sim.js js/sim.js
cp /tmp/payload/js/render.js js/render.js
cp /tmp/payload/js/main.js js/main.js
cp /tmp/payload/test/powers.mjs test/powers.mjs
cp /tmp/payload/test/quake_sample.mjs test/quake_sample.mjs
node --check js/sim.js
node --check js/render.js
node --check js/main.js
node test/powers.mjs
node test/quake_sample.mjs
node test/warhist.mjs
node test/smoke.mjs
