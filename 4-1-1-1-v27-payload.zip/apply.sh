set -e
SRC=/tmp/payload
DST=$(pwd)
mkdir -p "$DST/js" "$DST/test"
for f in js/sim.js js/render.js js/main.js style.css index.html README.md test/powers.mjs; do cp "$SRC/$f" "$DST/$f"; done
