#!/bin/bash
set -eo pipefail
cp /tmp/payload/econ.js js/econ.js
cp /tmp/payload/econ.mjs test/econ.mjs
node test/econ.mjs | tail -1
node test/ships.mjs | tail -1
