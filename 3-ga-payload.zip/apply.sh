set -e
cd "$GITHUB_WORKSPACE"
cp -r /tmp/payload/files/. .
echo "applied:"; ls -la README.md docs/spectate.png
