#!/bin/bash
set -e
cp /tmp/payload/style.css style.css
