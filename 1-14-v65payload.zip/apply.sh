#!/usr/bin/env bash
set -e
P="$(cd "$(dirname "$0")" && pwd)"
R="${GITHUB_WORKSPACE:-$(pwd)}"
cd "$P"
find . -type f ! -name apply.sh | while read -r f; do
  mkdir -p "$R/$(dirname "$f")"
  cp "$f" "$R/$f"
done
