#!/bin/bash
set -e
cp /tmp/payload/files/js/battles.js js/battles.js
cp /tmp/payload/files/js/units.js js/units.js
cp /tmp/payload/files/js/sim.js js/sim.js
cp /tmp/payload/files/js/main.js js/main.js
cp /tmp/payload/files/style.css style.css
cp /tmp/payload/files/README.md README.md
cp /tmp/payload/files/test/battles.mjs test/battles.mjs
git config user.name "sigco3111"
git config user.email "sigco3111@users.noreply.github.com"
git add js/battles.js js/units.js js/sim.js js/main.js style.css README.md test/battles.mjs
git commit -m "v67: 교전 결과 카드 - 개별 교전이 끝나면 양측 손실·승패·후퇴 방향·지휘관을 전쟁 탭 카드로 기록"
