#!/bin/bash
set -e
cp /tmp/payload/js/main.js js/main.js
node --check js/main.js
node test/warhist.mjs
node test/powers.mjs
node test/smoke.mjs
