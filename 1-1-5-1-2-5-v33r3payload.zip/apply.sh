#!/bin/bash
set -e
cp /tmp/payload/js/warhist.js js/warhist.js
cp /tmp/payload/test/warhist.mjs test/warhist.mjs
node test/warhist.mjs
