#!/bin/bash
cp /tmp/payload/js/units.js js/units.js
cp /tmp/payload/js/render.js js/render.js
rm -f js/2-units.js js/3-render.js
