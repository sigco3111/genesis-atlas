set -e
cp -r /tmp/payload/game/. .
