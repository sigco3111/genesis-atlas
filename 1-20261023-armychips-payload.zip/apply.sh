set -e
cp -f /tmp/payload/js/render.js js/
