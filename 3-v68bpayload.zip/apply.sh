#!/bin/bash
set -e
cp /tmp/payload/files/js/main.js js/main.js
git config user.name "sigco3111"
git config user.email "sigco3111@users.noreply.github.com"
git add js/main.js
git commit -m "v68b: 지휘관 전적 상세의 조사 교정 - 상대 국명 뒤 와/과를 받침에 맞게"
