set -e
REPO="${GITHUB_WORKSPACE:-$(pwd)}"
cd /tmp/payload
cp js/sim.js js/render.js "$REPO/js/"
cp test/ships.mjs test/carrsave.mjs test/carrrefund.mjs "$REPO/test/"
echo applied
