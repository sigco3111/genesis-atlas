#!/bin/bash
set -e
cp /tmp/payload/js/labels.js js/labels.js
cp /tmp/payload/js/render.js js/render.js
cp /tmp/payload/js/main.js js/main.js
cp /tmp/payload/test/labels.mjs test/labels.mjs
cp /tmp/payload/README.md README.md
git config user.name "sigco3111"
git config user.email "sigco3111@users.noreply.github.com"
git add -A
git commit -m "v66: 밀집 전장 표시 정리 - 부대 주변 도시 라벨 숨김, 병력 라벨 충돌 회피·예산, 추적 부대 금색 링·라벨"
