#!/bin/bash
set -e
cp /tmp/payload/js/labels.js js/labels.js
cp /tmp/payload/js/render.js js/render.js
cp /tmp/payload/test/labels.mjs test/labels.mjs
cp /tmp/payload/README.md README.md
git config user.name "sigco3111"
git config user.email "sigco3111@users.noreply.github.com"
git add -A
git commit -m "v66b: 밀집 전장 표시 정리 보강 - 부대 병력 라벨이 도시 라벨 상자도 피해 배치"
